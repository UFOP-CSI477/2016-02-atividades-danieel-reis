<?php
class Usuario extends AppModel {

}
?>
