<?php
class Paciente extends AppModel {
  
}
?>
