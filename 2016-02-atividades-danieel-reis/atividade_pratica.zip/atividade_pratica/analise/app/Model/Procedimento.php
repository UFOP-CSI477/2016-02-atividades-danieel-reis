<?php
class Procedimento extends AppModel {
  public $belongsTo = 'Usuario';
}
?>
